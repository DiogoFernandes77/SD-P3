/**
 *  Registration of remote objects in the local registry service.
 *
 *  Back engine application: code is moved and executed remotely in a platform supposed to be more powerful.
 *  Communication is based in Java RMI.
 */

package Simulation.registry;
