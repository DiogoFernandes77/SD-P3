/**
 * Package Client side of the Airport Simulation.
 *<br>Communication is based on message passing over sockets using the TCP protocol.
 */
package Simulation.client;