
kill -9 $(lsof -i:22358 -t) 2> /dev/null 
kill -9 $(lsof -i:22350 -t) 2> /dev/null 
kill -9 $(lsof -i:22351 -t) 2> /dev/null 
kill -9 $(lsof -i:22352 -t) 2> /dev/null 
kill -9 $(lsof -i:22353 -t) 2> /dev/null 
kill -9 $(lsof -i:22354 -t) 2> /dev/null 
kill -9 $(lsof -i:22355 -t) 2> /dev/null 
kill -9 $(lsof -i:22356 -t) 2> /dev/null 
kill -9 $(lsof -i:22357 -t) 2> /dev/null 
kill -9 $(lsof -i:22359 -t) 2> /dev/null 

