package Simulation;

public class Parameters {
    
    public final static String DEPART_AIRPORT_HOSTNAME = "l040101-ws08.ua.pt";

    public final static int DEPART_AIRPORT_PORT = 22350;

    public final static String DEPART_AIRPORT_NAME_ENTRY = "DepartAirportHandler";
    


    public final static String PLANE_HOSTNAME = "l040101-ws02.ua.pt";

    public final static int PLANE_PORT = 22351;
    
    public final static String PLANE_NAME_ENTRY = "PlaneHandler";
    
    
    public final static String DESTINATION_AIRPORT_HOSTNAME = "l040101-ws03.ua.pt";

    public final static int DESTINATION_AIRPORT_PORT = 22352;
    
    public final static String DESTINATION_AIRPORT_NAME_ENTRY = "DestinationAirportHandler";
    
    
    public final static String LOGGER_HOSTNAME = "l040101-ws04.ua.pt";

    public final static int LOGGER_PORT = 22353;

    public final static String LOGGER_NAME_ENTRY = "LoggerHandler";

    
    public final static String REGISTRY_HOSTNAME = "l040101-ws09.ua.pt";
    
    public final static int REGISTRY_PORT = 22358;

    public final static String REGISTRY_NAME_ENTRY = "RegistryHandler";

    public final static String SERVER_REGISTRY_HOSTNAME = "l040101-ws09.ua.pt";
    
    public final static int SERVER_REGISTRY_PORT = 22359;




    // public final static String DEPART_AIRPORT_HOSTNAME = "localhost";

    // public final static int DEPART_AIRPORT_PORT = 22350;

    // public final static String DEPART_AIRPORT_NAME_ENTRY = "DepartAirportHandler";
    


    // public final static String PLANE_HOSTNAME = "localhost";

    // public final static int PLANE_PORT = 22351;
    
    // public final static String PLANE_NAME_ENTRY = "PlaneHandler";
    
    
    // public final static String DESTINATION_AIRPORT_HOSTNAME = "localhost";

    // public final static int DESTINATION_AIRPORT_PORT = 22352;
    
    // public final static String DESTINATION_AIRPORT_NAME_ENTRY = "DestinationAirportHandler";
    
    
    // public final static String LOGGER_HOSTNAME = "localhost";

    // public final static int LOGGER_PORT = 22353;

    // public final static String LOGGER_NAME_ENTRY = "LoggerHandler";

    
    // public final static String REGISTRY_HOSTNAME = "localhost";
    
    // public final static int REGISTRY_PORT = 22358;

    // public final static String REGISTRY_NAME_ENTRY = "RegistryHandler";

    
    
    // public final static String SERVER_REGISTRY_HOSTNAME = "localhost";
    
    // public final static int SERVER_REGISTRY_PORT = 22359;

}
