find . -type f -path "*" -name "*.class" -exec rm -f {} \;
